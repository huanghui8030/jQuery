var imgData = [
	{
		src: 'images/kc/01.jpg',
		title: '图1',
		name: '图1'
	},
	{
		src: 'images/kc/02.jpg',
		title: '图2',
		name: '图2'
	},
	{
		src: 'images/kc/03.jpg',
		title: 'a3.jpg',
		name: '图3'
	},
	{
		src: 'images/kc/04.jpg',
		title: '---4',
		name: '图4'
	},
	{
		src: 'images/kc/05.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/06.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/07.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/08.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/09.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/10.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/11.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/12.jpg',
		title: '图5',
		name: '图6'
	},
	{
		src: 'images/kc/13.jpg',
		title: '图5',
		name: '图6'
	}
];
